function myFunction(){
  var c3 = document.getElementById("c3");
  var c32 = document.getElementById("c32");
  var c33 = document.getElementById("c33");
   var c39 = document.getElementById("c39");
  if (c3.checked == true){
    c32.style.display = "block";
	 c33.style.display = "block";
  } else {
    c32.style.display = "none";
	 c33.style.display = "none";
	 	 c39.style.display = "none";
  }
}
document.getElementById("c42").onmouseover = function() {mouseOver()};
document.getElementById("c42").onmouseout = function() {mouseOut()};
function mouseOver() {
  document.getElementById("c42").textContent = "1000 € ";
}
function mouseOut() {
  document.getElementById("c42").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c34").click(function(){
	$("#c39").hide();
	});
 });
 $(document).ready(function(){
  $("#c34").click(function(){
    $("#c32").show();
	});
 });
 $(document).ready(function(){
  $("#c35").click(function(){
	$("#c32").hide();
	});
 });
 $(document).ready(function(){
  $("#c35").click(function(){
    $("#c39").show();
	});
 });
 
function myFunction1(){
  var c4 = document.getElementById("c4");
  var c43 = document.getElementById("c43");
  var c46 = document.getElementById("c46");
   var c48 = document.getElementById("c48");
  if (c4.checked == true){
    c43.style.display = "block";
	 c46.style.display = "block";
  } else {
    c43.style.display = "none";
	 c46.style.display = "none";
	 	 c48.style.display = "none";
  }
}
document.getElementById("c47").onmouseover = function() {mouseOver1()};
document.getElementById("c47").onmouseout = function() {mouseOut1()};
function mouseOver1() {
  document.getElementById("c47").textContent = "1100 € ";
}
function mouseOut1() {
  document.getElementById("c47").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c44").click(function(){
	$("#c48").hide();
	});
 });
 $(document).ready(function(){
  $("#c44").click(function(){
    $("#c46").show();
	});
 });
 $(document).ready(function(){
  $("#c45").click(function(){
	$("#c46").hide();
	});
 });
 $(document).ready(function(){
  $("#c45").click(function(){
    $("#c48").show();
	});
 }); 
 
 
 
 
 function myFunction2(){
  var c5 = document.getElementById("c5");
  var c51 = document.getElementById("c51");
  var c54 = document.getElementById("c54");
   var c57 = document.getElementById("c57");
  if (c5.checked == true){
    c51.style.display = "block";
	 c54.style.display = "block";
  } else {
    c51.style.display = "none";
	c54.style.display = "none";
	c57.style.display = "none";
  }
}
document.getElementById("c56").onmouseover = function() {mouseOver2()};
document.getElementById("c56").onmouseout = function() {mouseOut2()};
function mouseOver2() {
  document.getElementById("c56").textContent = "900 € ";
}
function mouseOut2() {
  document.getElementById("c56").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c52").click(function(){
	$("#c57").hide();
	});
 });
 $(document).ready(function(){
  $("#c52").click(function(){
    $("#c54").show();
	});
 });
 $(document).ready(function(){
  $("#c53").click(function(){
	$("#c54").hide();
	});
 });
 $(document).ready(function(){
  $("#c53").click(function(){
    $("#c57").show();
	});
 }); 
 
 
 
  function myFunction3(){
  var c6 = document.getElementById("c6");
  var c61 = document.getElementById("c61");
  var c64 = document.getElementById("c64");
   var c67 = document.getElementById("c67");
  if (c6.checked == true){
    c61.style.display = "block";
	 c64.style.display = "block";
  } else {
    c61.style.display = "none";
	 c64.style.display = "none";
	  c67.style.display = "none";
  }
}
document.getElementById("c66").onmouseover = function() {mouseOver3()};
document.getElementById("c66").onmouseout = function() {mouseOut3()};
function mouseOver3() {
  document.getElementById("c66").textContent = "850 € ";
}
function mouseOut3() {
  document.getElementById("c66").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c62").click(function(){
	$("#c67").hide();
	});
 });
 $(document).ready(function(){
  $("#c62").click(function(){
    $("#c64").show();
	});
 });
 $(document).ready(function(){
  $("#c63").click(function(){
	$("#c64").hide();
	});
 });
 $(document).ready(function(){
  $("#c63").click(function(){
    $("#c67").show();
	});
 }); 
 
 
 
 
  function myFunction4(){
  var c7 = document.getElementById("c7");
  var c71 = document.getElementById("c71");
  var c74 = document.getElementById("c74");
   var c77 = document.getElementById("c77");
  if (c7.checked == true){
    c71.style.display = "block";
	 c74.style.display = "block";
  } else {
    c71.style.display = "none";
	 c74.style.display = "none";
	  c77.style.display = "none";
  }
}
document.getElementById("c76").onmouseover = function() {mouseOver4()};
document.getElementById("c76").onmouseout = function() {mouseOut4()};
function mouseOver4() {
  document.getElementById("c76").textContent = "800 € ";
}
function mouseOut4() {
  document.getElementById("c76").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c72").click(function(){
	$("#c77").hide();
	});
 });
 $(document).ready(function(){
  $("#c72").click(function(){
    $("#c74").show();
	});
 });
 $(document).ready(function(){
  $("#c73").click(function(){
	$("#c74").hide();
	});
 });
 $(document).ready(function(){
  $("#c73").click(function(){
    $("#c77").show();
	});
 }); 
 
 
 
  
    function myFunction5(){
  var c8 = document.getElementById("c8");
  var c81 = document.getElementById("c81");
  var c84 = document.getElementById("c84");
   var c87 = document.getElementById("c87");
  if (c8.checked == true){
    c81.style.display = "block";
	 c84.style.display = "block";
  } else {
    c81.style.display = "none";
	 c84.style.display = "none";
	  c87.style.display = "none";
  }
}
document.getElementById("c86").onmouseover = function() {mouseOver5()};
document.getElementById("c86").onmouseout = function() {mouseOut5()};
function mouseOver5() {
  document.getElementById("c86").textContent = "880 € ";
}
function mouseOut5() {
  document.getElementById("c86").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c82").click(function(){
	$("#c87").hide();
	});
 });
 $(document).ready(function(){
  $("#c82").click(function(){
    $("#c84").show();
	});
 });
 $(document).ready(function(){
  $("#c83").click(function(){
	$("#c84").hide();
	});
 });
 $(document).ready(function(){
  $("#c83").click(function(){
    $("#c87").show();
	});
 }); 
 
 
 
  
      function myFunction6(){
  var c9 = document.getElementById("c9");
  var c91 = document.getElementById("c91");
  var c94 = document.getElementById("c94");
   var c97 = document.getElementById("c97");
  if (c9.checked == true){
    c91.style.display = "block";
	 c94.style.display = "block";
  } else {
    c91.style.display = "none";
	 c94.style.display = "none";
	  c97.style.display = "none";
  }
}
document.getElementById("c96").onmouseover = function() {mouseOver6()};
document.getElementById("c96").onmouseout = function() {mouseOut6()};
function mouseOver6() {
  document.getElementById("c96").textContent = "730 € ";
}
function mouseOut6() {
  document.getElementById("c96").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c92").click(function(){
	$("#c97").hide();
	});
 });
 $(document).ready(function(){
  $("#c92").click(function(){
    $("#c94").show();
	});
 });
 $(document).ready(function(){
  $("#c93").click(function(){
	$("#c94").hide();
	});
 });
 $(document).ready(function(){
  $("#c93").click(function(){
    $("#c97").show();
	});
 }); 
 
 
 
    function myFunction7(){
  var c10 = document.getElementById("c10");
  var c101 = document.getElementById("c101");
  var c104 = document.getElementById("c104");
   var c107 = document.getElementById("c107");
  if (c10.checked == true){
    c101.style.display = "block";
	 c104.style.display = "block";
  } else {
    c101.style.display = "none";
	 c104.style.display = "none";
	  c107.style.display = "none";
  }
}
document.getElementById("c106").onmouseover = function() {mouseOver7()};
document.getElementById("c106").onmouseout = function() {mouseOut7()};
function mouseOver7() {
  document.getElementById("c106").textContent = "690 € ";
}
function mouseOut7() {
  document.getElementById("c106").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c102").click(function(){
	$("#c107").hide();
	});
 });
 $(document).ready(function(){
  $("#c102").click(function(){
    $("#c104").show();
	});
 });
 $(document).ready(function(){
  $("#c103").click(function(){
	$("#c104").hide();
	});
 });
 $(document).ready(function(){
  $("#c103").click(function(){
    $("#c107").show();
	});
 }); 
 
 
 
      function myFunction8(){
  var c17 = document.getElementById("c17");
  var c111 = document.getElementById("c111");
  var c114 = document.getElementById("c114");
   var c117 = document.getElementById("c117");
  if (c17.checked == true){
    c111.style.display = "block";
	 c114.style.display = "block";
  } else {
    c111.style.display = "none";
	 c114.style.display = "none";
	  c117.style.display = "none";
  }
}
document.getElementById("c116").onmouseover = function() {mouseOver8()};
document.getElementById("c116").onmouseout = function() {mouseOut8()};
function mouseOver8() {
  document.getElementById("c116").textContent = "640 € ";
}
function mouseOut8() {
  document.getElementById("c116").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c112").click(function(){
	$("#c117").hide();
	});
 });
 $(document).ready(function(){
  $("#c112").click(function(){
    $("#c114").show();
	});
 });
 $(document).ready(function(){
  $("#c113").click(function(){
	$("#c114").hide();
	});
 });
 $(document).ready(function(){
  $("#c113").click(function(){
    $("#c117").show();
	});
 }); 
 
 
 
      function myFunction9(){
  var c18 = document.getElementById("c18");
  var c121 = document.getElementById("c121");
  var c124 = document.getElementById("c124");
   var c127 = document.getElementById("c127");
  if (c18.checked == true){
    c121.style.display = "block";
	 c124.style.display = "block";
  } else {
    c121.style.display = "none";
	 c124.style.display = "none";
	  c127.style.display = "none";
  }
}
document.getElementById("c126").onmouseover = function() {mouseOver9()};
document.getElementById("c126").onmouseout = function() {mouseOut9()};
function mouseOver9() {
  document.getElementById("c126").textContent = "550 € ";
}
function mouseOut9() {
  document.getElementById("c126").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c122").click(function(){
	$("#c127").hide();
	});
 });
 $(document).ready(function(){
  $("#c122").click(function(){
    $("#c124").show();
	});
 });
 $(document).ready(function(){
  $("#c123").click(function(){
	$("#c124").hide();
	});
 });
 $(document).ready(function(){
  $("#c123").click(function(){
    $("#c127").show();
	});
 }); 
 
 
 
      function myFunction10(){
  var c19 = document.getElementById("c19");
  var c131 = document.getElementById("c131");
  var c134 = document.getElementById("c134");
   var c137 = document.getElementById("c137");
  if (c19.checked == true){
    c131.style.display = "block";
	 c134.style.display = "block";
  } else {
    c131.style.display = "none";
	 c134.style.display = "none";
	  c137.style.display = "none";
  }
}
document.getElementById("c136").onmouseover = function() {mouseOver10()};
document.getElementById("c136").onmouseout = function() {mouseOut10()};
function mouseOver10() {
  document.getElementById("c136").textContent = "440 € ";
}
function mouseOut10() {
  document.getElementById("c136").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c132").click(function(){
	$("#c137").hide();
	});
 });
 $(document).ready(function(){
  $("#c132").click(function(){
    $("#c134").show();
	});
 });
 $(document).ready(function(){
  $("#c133").click(function(){
	$("#c134").hide();
	});
 });
 $(document).ready(function(){
  $("#c133").click(function(){
    $("#c137").show();
	});
 }); 
 
 
 
      function myFunction11(){
  var c20 = document.getElementById("c20");
  var c141 = document.getElementById("c141");
  var c144 = document.getElementById("c144");
   var c147 = document.getElementById("c147");
  if (c20.checked == true){
    c141.style.display = "block";
	 c144.style.display = "block";
  } else {
    c141.style.display = "none";
	 c144.style.display = "none";
	  c147.style.display = "none";
  }
}
document.getElementById("c146").onmouseover = function() {mouseOver11()};
document.getElementById("c146").onmouseout = function() {mouseOut11()};
function mouseOver11() {
  document.getElementById("c146").textContent = "330 € ";
}
function mouseOut11() {
  document.getElementById("c146").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c142").click(function(){
	$("#c147").hide();
	});
 });
 $(document).ready(function(){
  $("#c142").click(function(){
    $("#c144").show();
	});
 });
 $(document).ready(function(){
  $("#c143").click(function(){
	$("#c144").hide();
	});
 });
 $(document).ready(function(){
  $("#c143").click(function(){
    $("#c147").show();
	});
 }); 
 
 
 
  
     function myFunction12(){
  var c22 = document.getElementById("c22");
  var c151 = document.getElementById("c151");
  var c154 = document.getElementById("c154");
   var c157 = document.getElementById("c157");
  if (c22.checked == true){
    c151.style.display = "block";
	 c154.style.display = "block";
  } else {
    c151.style.display = "none";
	 c154.style.display = "none";
	  c157.style.display = "none";
  }
}
document.getElementById("c156").onmouseover = function() {mouseOver12()};
document.getElementById("c156").onmouseout = function() {mouseOut12()};
function mouseOver12() {
  document.getElementById("c156").textContent = "450 € ";
}
function mouseOut12() {
  document.getElementById("c156").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c152").click(function(){
	$("#c157").hide();
	});
 });
 $(document).ready(function(){
  $("#c152").click(function(){
    $("#c154").show();
	});
 });
 $(document).ready(function(){
  $("#c153").click(function(){
	$("#c154").hide();
	});
 });
 $(document).ready(function(){
  $("#c153").click(function(){
    $("#c157").show();
	});
 }); 
 
 
 
  
      function myFunction13(){
  var c23 = document.getElementById("c23");
  var c161 = document.getElementById("c161");
  var c164 = document.getElementById("c164");
   var c167 = document.getElementById("c167");
  if (c23.checked == true){
    c161.style.display = "block";
	 c164.style.display = "block";
  } else {
    c161.style.display = "none";
	 c164.style.display = "none";
	  c167.style.display = "none";
  }
}
document.getElementById("c166").onmouseover = function() {mouseOver13()};
document.getElementById("c166").onmouseout = function() {mouseOut13()};
function mouseOver13() {
  document.getElementById("c166").textContent = "360 € ";
}
function mouseOut13() {
  document.getElementById("c166").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c162").click(function(){
	$("#c167").hide();
	});
 });
 $(document).ready(function(){
  $("#c162").click(function(){
    $("#c164").show();
	});
 });
 $(document).ready(function(){
  $("#c163").click(function(){
	$("#c164").hide();
	});
 });
 $(document).ready(function(){
  $("#c163").click(function(){
    $("#c167").show();
	});
 }); 
 
 
 
  
   function myFunction14(){
  var c24 = document.getElementById("c24");
  var c171 = document.getElementById("c171");
  var c174 = document.getElementById("c174");
   var c177 = document.getElementById("c177");
  if (c24.checked == true){
    c171.style.display = "block";
	 c174.style.display = "block";
  } else {
    c171.style.display = "none";
	 c174.style.display = "none";
	  c177.style.display = "none";
  }
}
document.getElementById("c176").onmouseover = function() {mouseOver14()};
document.getElementById("c176").onmouseout = function() {mouseOut14()};
function mouseOver14() {
  document.getElementById("c176").textContent = "400 € ";
}
function mouseOut14() {
  document.getElementById("c176").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c172").click(function(){
	$("#c177").hide();
	});
 });
 $(document).ready(function(){
  $("#c172").click(function(){
    $("#c174").show();
	});
 });
 $(document).ready(function(){
  $("#c173").click(function(){
	$("#c174").hide();
	});
 });
 $(document).ready(function(){
  $("#c173").click(function(){
    $("#c177").show();
	});
 }); 
 
 
 
   
      function myFunction15(){
  var c25 = document.getElementById("c25");
  var c181 = document.getElementById("c181");
  var c184 = document.getElementById("c184");
   var c187 = document.getElementById("c187");
  if (c25.checked == true){
    c181.style.display = "block";
	 c184.style.display = "block";
  } else {
    c181.style.display = "none";
	 c184.style.display = "none";
	  c187.style.display = "none";
  }
}
document.getElementById("c186").onmouseover = function() {mouseOver15()};
document.getElementById("c186").onmouseout = function() {mouseOut15()};
function mouseOver15() {
  document.getElementById("c186").textContent = "270 € ";
}
function mouseOut15() {
  document.getElementById("c186").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c182").click(function(){
	$("#c187").hide();
	});
 });
 $(document).ready(function(){
  $("#c182").click(function(){
    $("#c184").show();
	});
 });
 $(document).ready(function(){
  $("#c183").click(function(){
	$("#c184").hide();
	});
 });
 $(document).ready(function(){
  $("#c183").click(function(){
    $("#c187").show();
	});
 }); 
 
 
 
   function myFunction16(){
  var c27 = document.getElementById("c27");
  var c191 = document.getElementById("c191");
  var c194 = document.getElementById("c194");
   var c197 = document.getElementById("c197");
  if (c27.checked == true){
    c191.style.display = "block";
	 c194.style.display = "block";
  } else {
    c191.style.display = "none";
	 c194.style.display = "none";
	  c197.style.display = "none";
  }
}
document.getElementById("c196").onmouseover = function() {mouseOver16()};
document.getElementById("c196").onmouseout = function() {mouseOut16()};
function mouseOver16() {
  document.getElementById("c196").textContent = "370 € ";
}
function mouseOut16() {
  document.getElementById("c196").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c192").click(function(){
	$("#c197").hide();
	});
 });
 $(document).ready(function(){
  $("#c192").click(function(){
    $("#c194").show();
	});
 });
 $(document).ready(function(){
  $("#c193").click(function(){
	$("#c194").hide();
	});
 });
 $(document).ready(function(){
  $("#c193").click(function(){
    $("#c197").show();
	});
 }); 
 
 
 
   
  function myFunction17(){
  var c28 = document.getElementById("c28");
  var c201 = document.getElementById("c201");
  var c204 = document.getElementById("c204");
   var c207 = document.getElementById("c207");
  if (c28.checked == true){
    c201.style.display = "block";
	 c204.style.display = "block";
  } else {
    c201.style.display = "none";
	 c204.style.display = "none";
	  c207.style.display = "none";
  }
}
document.getElementById("c206").onmouseover = function() {mouseOver17()};
document.getElementById("c206").onmouseout = function() {mouseOut17()};
function mouseOver17() {
  document.getElementById("c206").textContent = "350 € ";
}
function mouseOut17() {
  document.getElementById("c206").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c202").click(function(){
	$("#c207").hide();
	});
 });
 $(document).ready(function(){
  $("#c202").click(function(){
    $("#c204").show();
	});
 });
 $(document).ready(function(){
  $("#c203").click(function(){
	$("#c204").hide();
	});
 });
 $(document).ready(function(){
  $("#c203").click(function(){
    $("#c207").show();
	});
 }); 
 
 
 
   
    function myFunction18(){
  var c29 = document.getElementById("c29");
  var c211 = document.getElementById("c211");
  var c214 = document.getElementById("c214");
   var c217 = document.getElementById("c217");
  if (c29.checked == true){
    c211.style.display = "block";
	 c214.style.display = "block";
  } else {
    c211.style.display = "none";
	 c214.style.display = "none";
	  c217.style.display = "none";
  }
}
document.getElementById("c216").onmouseover = function() {mouseOver18()};
document.getElementById("c216").onmouseout = function() {mouseOut18()};
function mouseOver18() {
  document.getElementById("c216").textContent = "350 € ";
}
function mouseOut18() {
  document.getElementById("c216").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c212").click(function(){
	$("#c217").hide();
	});
 });
 $(document).ready(function(){
  $("#c212").click(function(){
    $("#c214").show();
	});
 });
 $(document).ready(function(){
  $("#c213").click(function(){
	$("#c214").hide();
	});
 });
 $(document).ready(function(){
  $("#c213").click(function(){
    $("#c217").show();
	});
 }); 
 
 
 
   
    function myFunction19(){
  var c30 = document.getElementById("c30");
  var c221 = document.getElementById("c221");
  var c224 = document.getElementById("c224");
   var c227 = document.getElementById("c227");
  if (c30.checked == true){
    c221.style.display = "block";
	 c224.style.display = "block";
  } else {
    c221.style.display = "none";
	 c224.style.display = "none";
	  c227.style.display = "none";
  }
}
document.getElementById("c226").onmouseover = function() {mouseOver19()};
document.getElementById("c226").onmouseout = function() {mouseOut19()};
function mouseOver19() {
  document.getElementById("c226").textContent = "390 € ";
}
function mouseOut19() {
  document.getElementById("c226").textContent = "Viewed";
}
 $(document).ready(function(){
  $("#c222").click(function(){
	$("#c227").hide();
	});
 });
 $(document).ready(function(){
  $("#c222").click(function(){
    $("#c224").show();
	});
 });
 $(document).ready(function(){
  $("#c223").click(function(){
	$("#c224").hide();
	});
 });
 $(document).ready(function(){
  $("#c223").click(function(){
    $("#c227").show();
	});
 }); 
 
 
 
   
   