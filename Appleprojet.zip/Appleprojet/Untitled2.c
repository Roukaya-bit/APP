#include<stdio.h>

 typedef struct
 {char ARTICLE;
 int code;
 int NBRE;
 float P-Unite;
 float MONTANT;}
 Facture

 void fonct(int code,int NBRE)
 {
 if(code==25);{
 printf("Quantit� de centrifugeuse aux pris unitaire de 370.00");
 scanf("%d",&NBRE);
 }
 if(code==16){
 printf("Quantit� de centrifugeuse aux pris unitaire de 199.50");
 scanf("%d",&NBRE);}
 if(code==26){
 printf("Quantit� de centrifugeuse aux pris unitaire de 295.25");
 scanf("%d",&NBRE);}
 else{
 printf("**article inexistant-redonez le code");
 scanf("%d",&NBRE);}
 }

   void affiche(Facture x)
  {
  if(code==25)
  {
  ARTICLE=Centifuge;
  int NBRE;
  P-Unite=370.00;
  MONTANT=NBRE*370.00;}
  if(code==16)
  {
  ARTICLE=Grille-paix;
  int NBRE;
  P-Unite=199.50;
  MONTANT=NBRE*199.50;}
  if(code==26)
   {
  ARTICLE=Four raclette 6p;
  int NBRE;
  P-Unite=295.00;
  MONTANT=NBRE*295.00;}
  else
  { return o;}

 void main()
 {
 int n=3;
 Facture x;
 printf("Combien d'article a effectuer");
 scanf("%d"'&n');
 void fonct(int code,int NBRE)
 printf("donner le code");
 scanf("%d %d %d %d";&code,&code,&code,&code);
 void affiche(Facture x)
  float Total=NBRE*370.00+NBRE*199.50+NBRE*295.25;
  printf("Total");
  scanf ("%f";&Total);
  }
